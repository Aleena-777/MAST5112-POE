import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import {COLOURS} from './Colours';
import {formatPrice} from './Helpers';

export default function Menucard({item, onPress}) {
  return (
    <TouchableOpacity
    style={styles.card}
    onPress={() => onPress(item)}
    activeOpacity={0.85}
    >
    <View style={styles.info}>
    <Text style = {styles.name} numberOfLines={1}>
    {item.dishName}
    </Text>
    <Text style={styles.course}>{item.course}</Text>
    </View>
    <Text style={styles.price}>{formatPrice(item.price)}</Text>
    <Text style={styles.chevron}>›</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLOURS.cardDark,
    borderRadius: 12,
    paddingVertical: 15,
    paddingHorizontal: 16,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  info: {
    flex: 1,
    paddingRight: 8,
  },
  name: {
    color: COLOURS.white,
    fontSize: 16,
    fontWeight: 'bold',
  },
  course: {
    color: '#9AA3B5',
    fontSize: 12,
    marginTop: 3,
  },
  price: {
    color: COLOURS.white,
    fontSize: 14,
    fontWeight: '600',
    marginRight: 10,
  },
  chevron: {
    color: COLOURS.white,
    fontSize: 22,
  },
});
  
