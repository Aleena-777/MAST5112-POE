import {COURSES} from './Colours';

export const ALL_COURSES = 'ALL';
export const MAX_DISH_NAME_LENGTH = 40;
export const MAX_DESCRIPTION_LENGTH = 150;
export const MAX_PRICE = 10000;

//Turns the text typed by the chef into a number.
export function parsePrice(priceText) {
  return Number(String(priceText).trim().replace(',','.'));
}

//Turns a number into display text.
export function formatPrice(price) {
  return `R${Number(price).toFixed(2)}`;
}

export function createMenuItemId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function buildMenuItem(formValues, id = createMenuItemId()) {
  return {
    id,
    dishName: formValues.dishName.trim(),
    course: formValues.course,
    price: Math.round(parsePrice(formValues.price) * 100) / 100,
    description: formValues.description.trim(),
  };
}

export function validateMenuItemForm(formValues, existingItems, editingItemId = null) {
  const errors = {};
  const dishName = formValues.dishName.trim();
  const description = formValues.description.trim();
  const priceText = formValues.price.trim();

  if (!dishName) {
    errors.dishName = 'Dish name is required.';
  } else if (dishName.length < 2) {
    errors.dishName = 'Dish name must be at least 2 characters.';
  } else if (dishName.length > MAX_DISH_NAME_LENGTH) {
    errors.dishName = `Dish name must be ${MAX_DISH_NAME_LENGTH} characters or fewer.`;
  } else {
    const isDuplicate = existingItems.some(
      (item) =>
      item.id !== editingItemId &&
      item.dishName.toLowerCase() === dishName.toLowerCase()
    );
    if (isDuplicate) {
      errors.dishName = 'A dish with this name already exists.';
    }
  }

  if (!formValues.course) {
    errors.course = 'Please select a course.';
  }

  if (!priceText) {
    errors.price = 'Price is required.';
  } else {
    const price = parsePrice(priceText);
    if (isNaN(price) || price < 0.01) {
      errors.price = 'Enter a valid price greater than 0.';
    } else if (price > MAX_PRICE) {
      errors.price = `Price cannot be more than R${MAX_PRICE}.`;
    }
  }

  if (!description) {
    errors.description = 'Description is required.';
  } else if (description.length > MAX_DESCRIPTION_LENGTH) {
    errors.description = `Description must be ${MAX_DESCRIPTION_LENGTH} characters or fewer.`;
  }

  return errors;
}
  export function filterMenuItems(menuItems, searchText, selectedCourse) {
    const query = searchText.trim().toLowerCase();
    return menuItems.filter((item) => {
      const matchesName = item.dishName.toLowerCase().includes(query);
      const matchesCourse =
      selectedCourse === ALL_COURSES || item.course === selectedCourse;
      return matchesName && matchesCourse;
    });
  }

  export function calculateMenuStatistics(menuItems) {
    const totalItems = menuItems.length;
    const totalPrice = menuItems.reduce((sum, item) => sum + item.price, 0);
    const averagePrice = totalItems === 0 ? 0 : totalPrice / totalItems;

    const courseCounts = {};
    COURSES.forEach((course) => {
      courseCounts[course] = menuItems.filter((item) => item.course === course).length;
    });

    return {totalItems, averagePrice, courseCounts};
  }
