import React, {useEffect} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {COLOURS} from './Colours'

export default function Feedbackbanner({feedback, onDismiss}) {
  useEffect(() => {
    if (!feedback) {
      return undefined;
    }
    const timer = setTimeout(onDismiss, 2500);
    return () => clearTimeout(timer);
  }, [feedback]);

  if (!feedback) {
    return null;
  }

  return (
    <View style={styles.banner}>
    <Text style={styles.text}>✓ {feedback.text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    backgroundColor: COLOURS.successBackground,
    borderColor: COLOURS.successBorder,
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginHorizontal: 16,
    marginTop: 12,
  },
  text: {
    color: COLOURS.successText,
    fontSize: 14,
    fontWeight: '600',
  },
});