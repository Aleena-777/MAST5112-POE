import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {COLOURS, COURSES} from './Colours';
import {formatPrice} from './Helpers';

export default function Statscard({statistics}) {
  const {totalItems, averagePrice, courseCounts} = statistics;
  const averageText = totalItems === 0 ? '—' : formatPrice(averagePrice);

  return (
    <View style={styles.card}>
    <Text style={styles.title}>Menu Overview</Text> 

    <View style={styles.tileRow}>
    <View style={[styles.tile, styles.tileSpacing]}>
    <Text style={styles.tileValue}>{totalItems}</Text>
    <Text style={styles.tileLabel}>Total items</Text>
    </View>
    <View style={styles.tile}>
    <Text style={styles.tileValue}>{averageText}</Text>
    <Text style={styles.tileLabel}>Average price</Text>
    </View>
    </View>

    <Text style={styles.subtitle}>Items per course</Text>
    <View style={styles.courseRow}>
    {COURSES.map((course, index) => (
      <View
      key={course}
      style={[styles.courseBox, index < COURSES.length - 1 && styles.courseSpacing]}
      >
      <Text style={styles.courseCount}>{courseCounts[course] ?? 0}</Text>
      <Text style={styles.courseLabel} numberOfLines={1}>
      {course}
      </Text>
      </View>
    ))}
    </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLOURS.white,
    borderRadius: 14,
    padding: 14,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: COLOURS.border,
  },
  title: {
    fontSize: 15,
    fontWeight: 'bold',
    color: COLOURS.navy,
    marginBottom: 10,
  },
  tileRow: {
    flexDirection: 'row',
  },
  tile: {
    flex: 1,
    backgroundColor: COLOURS.navy,
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center',
  },
  tileSpacing: {
    marginRight: 10,
  },
  tileValue: {
    color: COLOURS.white,
    fontSize: 22,
    fontWeight: 'bold',
  },
  tileLabel: {
    color: '#C9D3E6',
    fontSize: 12,
    marginTop: 2,
  },
  subtitle: {
    fontSize: 13,
    fontWeight: '600',
    color: COLOURS.greyText,
    marginTop: 14,
    marginBottom: 8,
  },
  courseRow: {
    flexDirection: 'row',
  },
  courseBox: {
    flex: 1,
    backgroundColor: COLOURS.lavender,
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 2,
    alignItems: 'center',
  },
  courseSpacing: {
    marginRight: 8,
  },
  courseCount: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLOURS.navy,
  },
  courseLabel: {
    fontSize: 11,
    color: COLOURS.greyText,
    marginTop: 2,
  },
});