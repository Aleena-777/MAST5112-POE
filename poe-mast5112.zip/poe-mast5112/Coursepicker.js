import React, {useState} from 'react';
import {View, Text, TouchableOpacity, Modal, StyleSheet} from 'react-native';
import {COLOURS, COURSES} from './Colours';

export default function Coursepicker({label, selectedCourse, onSelect, error}) {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (course) => {
    onSelect(course);
    setIsOpen(false);
  };

  return (
    <View style={styles.wrapper}>
    <Text style={styles.label}>{label}</Text>
    <TouchableOpacity
    style={[styles.field, error && styles.fieldError]}
    onPress={() => setIsOpen(true)}
    >
    <Text style={selectedCourse ? styles.value : styles.placeholder}>
    {selectedCourse || 'Select course'}
    </Text>
    <Text style={styles.chevron}>⌄</Text>
    </TouchableOpacity>
    {error ? <Text style={styles.errorText}>{error}</Text> : null}

    <Modal
    visible={isOpen}
    transparent
    animationType="fade"
    onRequestClose={() => setIsOpen(false)}
    >
    <TouchableOpacity
    style={styles.overlay}
    activeOpacity={1}
    onPress={() => setIsOpen(false)}
    >
    <View style={styles.card}>
    <Text style={styles.cardTitle}>Select course</Text>
    {COURSES.map((course) => {
      const isSelected = course === selectedCourse;
      return (
        <TouchableOpacity
        key={course}
        style={styles.option}
        onPress={() => handleSelect(course)}
        >
        <Text style={[styles.optionText, isSelected && styles.optionTextSelected]}>
        {course}
        </Text>
        {isSelected ? <Text style={styles.check}>✓</Text> : null}
        </TouchableOpacity>
      );
    })}
    </View>
    </TouchableOpacity>
    </Modal>
    </View>
  );
}

const styles =StyleSheet.create({
  wrapper: {
    marginBottom: 14,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: COLOURS.navy,
    marginBottom: 6,
  },
  field: {
    backgroundColor: COLOURS.lavender,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 13,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: COLOURS.lavender,
  },
  fieldError: {
    borderolor: COLOURS.error,
    backgroundColor: COLOURS.errorBackground,
  },
  placeholder: {
    color: COLOURS.grey,
    fontSize: 15,
  },
  value: {
    color: COLOURS.navy,
    fontSize: 15,
    fontWeight: '600',
  },
  chevron: {
    color: COLOURS.greyText,
    fontSize: 16,
  },
  errorText: {
    color: COLOURS.error,
    fontSize: 12, 
    marginTop: 4,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    backgroundColor: COLOURS.white,
    borderRadius: 14,
    padding: 18,
    width: '80%',
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: COLOURS.navy,
    marginBottom: 8,
  },
  option: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 13,
    borderBottomWidth: 1,
    borderBottomColor: COLOURS.border,
  },
  optionText: {
    fontSize: 15,
    color: COLOURS.black,
  },
  optionTextSelected: {
    color: COLOURS.blue,
    fontWeight: 'bold',
  },
  check: {
    color: COLOURS.blue,
    fontSize: 16,
    fontWeight: 'bold',
  },
});