import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, StatusBar} from 'react-native';
import {COLOURS} from './Colours';

export default function Appheader({title, onBack}) {
  return (
    <View style={styles.header}>
    <StatusBar barStyle="light-content" />
    {onBack ? (
      <TouchableOpacity
      onPress={onBack}
      style={styles.sideSlot}
      accessibilityLabel="Go back"
      >
      <Text style={styles.backArrow}>‹</Text>
      </TouchableOpacity>
    ) : (
      <View style={styles.sideSlot} />
    )}
    <Text style={styles.title}>{title}</Text>
    <View style={styles.sideSlot} />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: COLOURS.navy,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 34,
    paddingBottom: 18,
    paddingHorizontal: 12,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  sideSlot: {
    width: 40,
    alignItems: 'center',
  },
  backArrow: {
    color: COLOURS.white,
    fontSize: 32,
    lineHeight: 34,
  },
  title: {
    color: COLOURS.white,
    fontSize: 20,
    fontWeight: 'bold',
  },
});