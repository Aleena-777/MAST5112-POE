import React from 'react';
import {Text, TouchableOpacity, StyleSheet} from 'react-native';
import {COLOURS} from './Colours';

const VARIANT_STYLES = {
  primary: {backgroundColor: COLOURS.blue},
  secondary: {backgroundColor: COLOURS.navy},
  dark: {backgroundColor: COLOURS.black},
  danger: {backgroundColor: COLOURS.error},
  outline: {
    backgroundColor: COLOURS.white,
    borderWidth: 1.5,
    borderColor: COLOURS.navy,
  },
};

export default function Actionbutton({label, onPress, variant = 'primary', style}) {
  const isOutline = variant === 'outline';
  return (
    <TouchableOpacity
    style={[styles.button, VARIANT_STYLES[variant], style]}
    onPress={onPress}
    activeOpacity={0.8}
    >
    <Text style={[styles.label, isOutline && styles.outlineLabel]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles =StyleSheet.create({
  button: {
    borderRadius: 28,
    paddingVertical: 15,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    color: COLOURS.white,
    fontSize: 16,
    fontWeight: 'bold',
  },
  outlineLabel: {
    color: COLOURS.navy,
  },
});