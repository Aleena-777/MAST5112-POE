import React from 'react';
import {View, Text, Modal, StyleSheet} from 'react-native';
import {COLOURS} from './Colours';
import Actionbutton from './Actionbutton';

export default function Confirmdialog({
  visible,
  title,
  message,
  confirmLabel,
  onConfirm,
  onCancel,
}) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
    <View style={styles.overlay}>
    <View style={styles.card}>
    <Text style={styles.title}>{title}</Text>
    <Text style={styles.message}>{message}</Text>
    <Actionbutton
    label={confirmLabel}
    onPress={onConfirm}
    variant="danger"
    style={styles.button}
    />
    <Actionbutton
    label="Cancel"
    onPress={onCancel}
    variant="outline"
    style={styles.button}
    />
    </View>
    </View>
    </Modal>
  );
}

const styles =StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    backgroundColor: COLOURS.white,
    borderRadius: 16,
    padding: 22,
    width: '85%',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLOURS.navy,
    marginBottom: 8,
  },
  message: {
    fontSize: 14,
    color: COLOURS.greyText,
    lineHeight: 20,
    marginBottom: 16,
  },
  button: {
    marginTop: 8,
    paddingVertical: 12,
  },
});