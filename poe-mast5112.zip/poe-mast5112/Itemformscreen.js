import React, {useState} from 'react';
import {SafeAreaView, ScrollView, KeyboardAvoidingView, Platform, StyleSheet,} from 'react-native';
import {COLOURS} from './Colours';
import {MAX_DESCRIPTION_LENGTH, MAX_DISH_NAME_LENGTH, buildMenuItem, validateMenuItemForm,} from './Helpers';
import Appheader from './Appheader';
import Formfield from './Formfield';
import Coursepicker from './Coursepicker';
import Actionbutton from './Actionbutton';

export default function Itemformscreen({itemToEdit, existingItems, onSave, onCancel}) {
  const isEditing = Boolean(itemToEdit);

  const [formValues, setFormValues] = useState({
    dishName: isEditing ? itemToEdit.dishName : '',
    course: isEditing ? itemToEdit.course : '',
    price: isEditing ? String(itemToEdit.price) : '',
    description: isEditing ? itemToEdit.description : '',
  });
  const [errors, setErrors] = useState({});

  const updateField = (fieldName, value) => {
    setFormValues((previous) => ({...previous, [fieldName]: value}));
    if (errors[fieldName]) {
      setErrors((previous) => ({...previous, [fieldName]: undefined}));
    }
  };

  const handleSave = () => {
    const editingItemId = isEditing ? itemToEdit.id : null;
    const validationErrors = validateMenuItemForm(formValues, existingItems, editingItemId);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      return;
    }
    onSave(buildMenuItem(formValues, isEditing ? itemToEdit.id : undefined));
  };

  return (
    <SafeAreaView style={styles.screen}>
    <Appheader title={isEditing ? 'Edit Menu Item' : 'Add Menu Item'} onBack={onCancel} />

    <KeyboardAvoidingView
    style={styles.flex}
    behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
    <ScrollView
    contentContainerStyle={styles.formBody}
    keyboardShouldPersistTaps="handled"
    >
    <Formfield
    label="Dish Name"
    placeholder="e.g. Iced Tea"
    value={formValues.dishName}
    onChangeText={(text) => updateField('dishName', text)}
    maxLength={MAX_DISH_NAME_LENGTH}
    error={errors.dishName}
    />

    <Coursepicker
    label="Course"
    selectedCourse={formValues.course}
    onSelect={(course) => updateField('course', course)}
    error={errors.course}
    />

    <Formfield
    label="Price (R)"
    placeholde="e.g. 20"
    value={formValues.price}
    onChangeText={(text) => updateField('price', text)}
    keyboardType="decimal-pad"
    error={errors.price}
    />

    <Formfield
    label="Description"
    placeholder="Short description of item"
    value={formValues.description}
    onChangeText={(text) => updateField('description', text)}
    maxLength={MAX_DESCRIPTION_LENGTH}
    multiline
    error={errors.description}
    />

    <Actionbutton
    label={isEditing ? 'Save Changes' : 'Save Menu Item'}
    onPress={handleSave}
    variant="secondary"
    style={styles.saveButton}
    />
    <Actionbutton
    label="Cancel"
    onPress={onCancel}
    variant="outline"
    style={styles.cancelButton}
    />
    </ScrollView>
    </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: COLOURS.white,
  },
  flex: {
    flex: 1,
  },
  formBody: {
    padding: 20,
    paddingBottom: 40,
  },
  saveButton: {
    marginTop: 12,
  },
  cancelButton: {
    marginTop: 12,
  },
});