import React from 'react';
import {ScrollView, TouchableOpacity, Text, StyleSheet} from 'react-native';
import {COLOURS, COURSES} from './Colours';
import {ALL_COURSES} from './Helpers';

const FILTER_OPTIONS = [ALL_COURSES, ...COURSES];

export default function Coursefilter({selectedCourse, onSelect}) {
  return (
    <ScrollView 
    horizontal
    showsHorizontalScrollIndicator={false}
    keyboardShouldPersistTaps="handled"
    contentContainerStyle={styles.row}
    >
    {FILTER_OPTIONS.map((option) => {
      const isSelected = option === selectedCourse;
      return (
        <TouchableOpacity
        key={option}
        style={[styles.chip, isSelected && styles.chipSelected]}
        onPress={() => onSelect(option)}
        >
        <Text style={[styles.chipText, isSelected && styles.chipTextSelected]}>
        {option}
        </Text>
        </TouchableOpacity>
      );
    })}
    </ScrollView>
  );
}

const styles =StyleSheet.create({
  row: {
    paddingVertical: 4,
  },
  chip: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    backgroundColor: COLOURS.white,
    borderWidth: 1,
    borderColor: COLOURS.navy,
    marginRight: 8,
  },
  chipSelected: {
    backgroundColor: COLOURS.navy,
  },
  chipText: {
    color: COLOURS.navy,
    fontSize: 13,
    fontWeight: '600',
  },
  chipTextSelected: {
    color: COLOURS.white,
  },
});