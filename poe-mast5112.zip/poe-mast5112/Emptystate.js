import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {COLOURS} from './Colours';
import Actionbutton from './Actionbutton';

export default function Emptystate({message, actionLabel, onAction}) {
  return (
    <View style={styles.box}>
    <Text style={styles.message}>{message}</Text>
    {actionLabel ? (
      <Actionbutton
      label={actionLabel}
      onPress={onAction}
      variant="outline"
      style={styles.action}
      />
    ) : null}
    </View>
  );
}

const styles =StyleSheet.create({
  box: {
    backgroundColor: COLOURS.white,
    borderRadius: 12,
    padding: 22,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLOURS.border,
    borderStyle: 'dashed',
  },
  message: {
    color: COLOURS.greyText,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  action: {
    marginTop: 14,
    paddingVertical: 10,
  },
});