import React, {useState} from 'react';
import {SafeAreaView, ScrollView, View, Text, StyleSheet} from 'react-native';
import {COLOURS} from './Colours.js';
import {formatPrice} from './Helpers';
import Appheader from './Appheader';
import Actionbutton from './Actionbutton';
import Confirmdialog from './Confirmdialog';

export default function DishdetailScreen({item, onBack, onEdit, onDelete}) {
  const [isDeleteDialogVisible, setIsDeleteDialogVisible] = useState(false);

  return(
    <SafeAreaView style={styles.screen}>
    <Appheader title="Dish Detail" onBack={onBack} />

    <ScrollView contentContainerStyle={styles.body}>
    <Text style={styles.name}>{item.dishName}</Text>
    <Text style={styles.bullet}>• Course: {item.course}</Text>
    <Text style={styles.bullet}>• Price: {formatPrice(item.price)}</Text>

   <Text style={styles.label}>Description:</Text>
   <Text style={styles.description}>{item.description}</Text>

   <View style={styles.buttonGroup}>
   <Actionbutton label="Edit Item" onPress={() => onEdit(item)} variant="primary" />
   <Actionbutton
   label="Delete Item"
   onPress={() => setIsDeleteDialogVisible(true)}
   variant="dark"
   style={styles.deleteButton}
   />
   </View>
   </ScrollView>

   <Confirmdialog
   visible={isDeleteDialogVisible}
   title="Delete this dish?"
   message={`"${item.dishName}" will be removed from the menu. This cannot be undone.`}
   confirmLabel="Yes, delete"
   onConfirm={() => {
     setIsDeleteDialogVisible(false);
     onDelete(item.id);
   }}
   onCancel={() => setIsDeleteDialogVisible(false)}
   />
   </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: COLOURS.white,
  },
  body: {
    padding: 20,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLOURS.black,
    marginBottom: 10,
  },
  bullet: {
    fontSize: 15,
    color: '#333333',
    marginBottom: 4,
  },
  label: {
    fontSize: 15,
    fontWeight: 'bold',
    color: COLOURS.black,
    marginTop: 20,
    marginBottom: 6,
      },
      description: {
        fontSize: 15,
        color: '#444444',
        lineHeight: 22,
      },
      buttonGroup: {
        marginTop: 36,
      },
      deleteButton: {
        marginTop: 12,
      },
});