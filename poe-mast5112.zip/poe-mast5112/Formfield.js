import React from 'react';
import {View, Text, TextInput, StyleSheet} from 'react-native';
import {COLOURS} from './Colours';

export default function Formfield({label, error, multiline = false, ...inputProps}) {
  return (
    <View style={styles.wrapper}>
    <Text style={styles.label}>{label}</Text>
    <TextInput
    style={[styles.input, multiline && styles.multiline, error && styles.inputError]}
    placeholderTextColor={COLOURS.grey}
    multiline={multiline}
    {...inputProps}
    />
    {error ? <Text style={styles.errorText}>{error}</Text> : null}
    </View>
  );
}

const styles =StyleSheet.create({
  wrapper: {
    marginBottom: 14,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: COLOURS.navy,
    marginBottom: 6,
  },
  input: {
    backgroundColor: COLOURS.lavender,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: COLOURS.navy,
    borderWidth: 1,
    borderColor: COLOURS.lavender,
  },
  multiline: {
    minHeight: 90,
    textAlignVertical: 'top',
  },
  inputError: {
    borderColor: COLOURS.error,
    backgroundColor: COLOURS.errorBackground,
  },
  errorText: {
    color: COLOURS.error,
    fontSize: 12,
    marginTop: 4
  },
});