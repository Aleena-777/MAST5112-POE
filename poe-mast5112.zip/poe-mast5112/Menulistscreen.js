import React from 'react';
import {SafeAreaView, View, Text, TextInput,TouchableOpacity, FlatList, StyleSheet,} from 'react-native';
import {COLOURS} from './Colours';
import {ALL_COURSES, calculateMenuStatistics, filterMenuItems} from './Helpers';
import Appheader from './Appheader';
import Actionbutton from './Actionbutton';
import Statscard from './Statscard';
import Coursefilter from './Coursefilter';
import Menucard from './Menucard';
import Emptystate from './Emptystate';
import Feedbackbanner from './Feedbackbanner';

export default function MenuListScreen({menuItems, searchText, selectedCourse, onSearchTextChange, onCourseChange, feedback, onDismissFeedback, onAddNewItem, onSelectItem,
}) {
  const hasItems = menuItems.length > 0;
  const statistics = calculateMenuStatistics(menuItems);
  const visibleItems = filterMenuItems(menuItems, searchText, selectedCourse);
  const isFiltering = searchText.trim() !== '' || selectedCourse !== ALL_COURSES;

  const clearSearchAndFilter = () => {
    onSearchTextChange('');
    onCourseChange(ALL_COURSES);
  };

  const listHeader = (
    <View>
    <Statscard statistics={statistics} />

    {hasItems ? (
      <View>
    <View style={styles.searchBar}>
    <Text style={styles.searchIcon}>🔍</Text>
    <TextInput
    style={styles.searchInput}
    placeholder="Search by dish name"
    placeholderTextColor={COLOURS.greyText}
    value={searchText}
    onChangeText={onSearchTextChange}
    autoCorrect={false}
    returnKeyType="search"
    />
    {searchText.length > 0 ? (
      <TouchableOpacity
      onPress={() => onSearchTextChange('')}
      accessibilityLabel="Clear search text"
      >
      <Text style={styles.clearIcon}>✕</Text>
      </TouchableOpacity>
    ) : null}
    </View>

    <Coursefilter selectedCourse={selectedCourse} onSelect={onCourseChange} />

    <View style={styles.resultsRow}>
    <Text style={styles.resultsText}>
    {isFiltering
    ? `Showing ${visibleItems.length} of ${menuItems.length} items` : `All items (${menuItems.length})`}
    </Text>
    {isFiltering ? (
      <TouchableOpacity onPress={clearSearchAndFilter}>
      <Text style={styles.clearLink}>Clear search & filter</Text>
      </TouchableOpacity>
    ) : null}
    </View>
    </View>
    ) : null}
    </View>
  );

  const emptyMessage = hasItems ? (
    <Emptystate
    message="No dishes match your search or filter."
    actionLabel="Clear search and filter"
    onAction={clearSearchAndFilter}
    />
  ) : (
    <Emptystate message={'No dishes have been added yet. Tap "+Add New Item" below to get started.'} />
  );

  return (
    <SafeAreaView style={styles.screen}>
    <Appheader title="Menu Manager"/>
    <Feedbackbanner feedback={feedback} onDismiss={onDismissFeedback} />

    <FlatList
    data={visibleItems}
    keyExtractor={(item) => item.id}
    renderItem={({item}) => <Menucard item={item} onPress={onSelectItem} />}
   ListHeaderComponent={listHeader}
   ListEmptyComponent={emptyMessage}
   contentContainerStyle={styles.listContent}
   keyboardShouldPersistTaps="handled"
   />

   <View style={styles.addButtonWrap}>
   <Actionbutton
   label="+ Add New Item"
   onPress={onAddNewItem}
   style={styles.addButton}
   />
   </View>
   </SafeAreaView>
  );
    }

const styles = StyleSheet.create({
screen: {
  flex: 1,
  backgroundColor: COLOURS.background,
},
listContent: {
  paddingHorizontal: 16,
  paddingTop: 14,
  paddingBottom: 12,
},
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLOURS.lavender,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
    marginBottom: 10,
  },
  searchIcon: {
    fontSize: 14,
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: COLOURS.navy,
    paddingVertical: 10,
  },
  clearIcon: {
    fontSize: 16,
    color: COLOURS.greyText,
    paddingHorizontal: 6,
  },
  resultsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 10,
  },
  resultsText: {
    fontSize: 13,
    fontWeight: '600',
    color: COLOURS.greyText,
  },
  clearLink: {
    fontSize: 13,
    fontWeight: 'bold',
    color: COLOURS.blue,
  },
  addButtonWrap: {
    alignItems: 'center',
    paddingVertical: 50,
  },
  addButton: {
    alignSelf: 'center',
    paddingVertical: 18,
    paddingHorizontal: 38,
  },
   });