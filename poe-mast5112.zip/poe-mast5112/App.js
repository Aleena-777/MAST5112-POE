import React, {useState} from 'react';
import {ALL_COURSES} from './Helpers';
import SplashScreen from './Splashscreen';
import MenuListScreen from './Menulistscreen';
import Itemformscreen from './Itemformscreen';
import DishdetailScreen from './Dishdetailscreen';

const SCREENS = {
  SPLASH: 'splash',
  LIST: 'list',
  FORM: 'form',
  DETAILS: 'details',
};
export default function App() {
  const [currentScreen, setCurrentScreen] = useState(SCREENS.SPLASH);

  const [menuItems, setMenuItems] = useState([]);
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [itemBeingEdited, setItemBeingEdited] = useState(null);
  const [feedback, setFeedback] = useState(null);

  const [searchText, setSearchText] = useState('');
  const [selectedCourse, setSelectedCourse] = useState(ALL_COURSES);

  const selectedItem = menuItems.find((item) => item.id === selectedItemId) || null;

  const showFeedback = (text) => setFeedback({id: Date.now(), text});
  const goToList = () => setCurrentScreen(SCREENS.LIST);

  const handleAddNewItem = () => {
    setItemBeingEdited(null);
    setCurrentScreen(SCREENS.FORM);
  };

  const handleSelectItem = (item) => {
    setSelectedItemId(item.id);
    setCurrentScreen(SCREENS.DETAILS);
  };

  const handleEditItem =(item) => {
    setItemBeingEdited(item);
    setCurrentScreen(SCREENS.FORM);
  };

  const handleCancelForm = () => {
    setCurrentScreen(itemBeingEdited ? SCREENS.DETAILS : SCREENS.LIST);
  };

  const handleSaveItem = (savedItem) => {
    const isUpdate = menuItems.some((item) => item.id === savedItem.id);

    if (isUpdate) {
      setMenuItems((previous) =>
      previous.map((item) => (item.id === savedItem.id ? savedItem : item))
      );
      showFeedback(`"${savedItem.dishName}" was updated.`);
    } else {
      setMenuItems((previous) => [...previous, savedItem]);
      setSearchText('');
      setSelectedCourse(ALL_COURSES);
      showFeedback(`"${savedItem.dishName}" was added to the menu.`);
    }

    setItemBeingEdited(null);
    goToList();
  };

  const handleDeleteItem = (itemId) => {
    const deletedItem = menuItems.find((item) => item.id === itemId);
    setMenuItems((previous) => previous.filter((item) => item.id !== itemId));
    setSelectedItemId(null);
    if (deletedItem) {
      showFeedback(`"${deletedItem.dishName}" was deleted.`);
    }
    goToList();
  };

  if (currentScreen === SCREENS.SPLASH) {
    return <SplashScreen onFinish={goToList} />;
  }

  if (currentScreen === SCREENS.FORM) {
    return (
      <Itemformscreen
      itemToEdit={itemBeingEdited}
      existingItems={menuItems}
      onSave={handleSaveItem}
      onCancel={handleCancelForm}
      />
    );
  }

  if (currentScreen === SCREENS.DETAILS && selectedItem) {
    return (
      <DishdetailScreen
      item={selectedItem}
      onBack={goToList}
      onEdit={handleEditItem}
      onDelete={handleDeleteItem}
      />
    );
  }

  return (
    <MenuListScreen
    menuItems={menuItems}
    searchText={searchText}
    selectedCourse={selectedCourse}
    onSearchTextChange={setSearchText}
    onCourseChange={setSelectedCourse}
    feedback={feedback}
    onDismissFeedback={() => setFeedback(null)}
    onAddNewItem={handleAddNewItem}
    onSelectItem={handleSelectItem}
    />
  );
}