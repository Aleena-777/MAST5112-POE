export const COLOURS = {
  navy: '#173A64',
  navyDark: '#0E2846',
  cardDark: '#12233F',
  lavender: '#E7E9F5',
  blue: '#3F6FBF',
  black: '#111111',
  white: '#FFFFFF',
  grey: '#8C93A6',
  greyText: '#6B7280',
  error: '#D64545',
  successBg: '#EAFAF1',
  successBorder: '#27AE60',
  successText: '#1E8449',
  background: '#F4F5FA',
  border: '#E2E5EC',
  errorBackground: '#FDECEC',
  successBackground: '#EAFAF1',
};

export const COURSES = ['Starter', 'Main', 'Dessert', 'Drink'];